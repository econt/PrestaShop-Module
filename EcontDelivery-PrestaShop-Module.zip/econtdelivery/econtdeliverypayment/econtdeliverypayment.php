<?php

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class EcontDeliveryPayment extends PaymentModule {

    // Колко дълго важи подписаният адрес за връщане от плащането (econtdeliverypayment_time), в секунди
    const RETURN_URL_TTL = 86400;

    private $hooks = array(
        'paymentOptions',
        'orderConfirmation'
    );

    public function __construct() {
        $this->name = 'econtdeliverypayment';
        $this->tab = 'payments_gateways';
        $this->version = '2.0.4'; // change from zip generator
        $this->ps_versions_compliancy = array(
            'min' => '1.7',
            'max' => _PS_VERSION_
        );
        $this->bootstrap = true;
        $this->author = 'ITPartner';
        $this->controllers = array('validation');

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        parent::__construct();

        $this->displayName = $this->l('EcontPay');
        $this->description = $this->l('Допълнение към модула "Достави с Еконт".');

        $this->confirmUninstall = $this->l('Сигурни ли сте, че искате да премахнете модула?');
    }

    public function install() {
        if (!parent::install()) return false;

        foreach ($this->hooks as $hook) if (!$this->registerHook($hook)) return false;

        return true;
    }
    public function uninstall() {
        if (!parent::uninstall()) return false;

        foreach ($this->hooks as $hook) if (!$this->unregisterHook($hook)) return false;

        return true;
    }

    public function logEvent($event) {
        $event['plugin_type'] = 'prestashop';
        $deliveryBaseURL = Configuration::get('ECONT_DELIVERY_ENDPOINT');
        $deliverySecret = Configuration::get('ECONT_DELIVERY_SECRET');
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "{$deliveryBaseURL}/services/PluginsService.logEvent.json");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            "Authorization: {$deliverySecret}"
        ]);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode([$event]));
        curl_setopt($curl, CURLOPT_TIMEOUT, 6);
        curl_exec($curl);
        curl_close($curl);
    }

    public function disable($force_all = false) {
        $this->logEvent(['action' => 'payment_enabled', 'value' => '0']);
        return parent::disable($force_all);
    }
    public function enable($force_all = false) {
        $this->logEvent(['action' => 'payment_enabled', 'value' => '1']);
        return parent::enable($force_all);
    }

    private function orderConfirmationMessage($message = 'Възникна грешка', $dontTranslate = false) {
        $message = "EcontPay: {$message}";
        return '<p class="text-danger">' . ($dontTranslate ? $message : $this->l($message)) . '</p>';
    }

    public function hookPaymentOptions($params) {
        /** @var Cart $cart */
        $cart = $params['cart'];

        if (!$this->active || $cart->id_carrier != Configuration::get('ECONT_DELIVERY_CARRIER_ID')) return null;

        $paymentOption = new PaymentOption();

        $paymentOption->setCallToActionText($this->l(Configuration::get('ECONT_DELIVERY_PAYMENT_TITLE')));
        $paymentOption->setAction($this->context->link->getModuleLink($this->name, 'validation', array()));
        ob_start() ;?>
        <?php $paymentLogo = trim(Configuration::get('ECONT_DELIVERY_PAYMENT_LOGO')); ?>
        <?php if (!empty($paymentLogo)): ?>
            <?php $econtDelivery = new EcontDelivery(); ?>
            <img src="<?php echo rtrim($this->context->link->getBaseLink(), '/')  . $econtDelivery->getPathUri() . "view/img/Econt_pay.svg"; ?>" alt="Econt Delivery Payment Logo" style="margin-bottom: 15px;">
        <?php endif; ?>
        <?php $additionalInformation = ob_get_contents();
        ob_end_clean();
        $paymentOption->setAdditionalInformation($additionalInformation);

        return array($paymentOption);
    }
    public function hookOrderConfirmation($params) {
        /** @var Order $order */
        $order = $params['order'];

        if (intval($order->id) <= 0 || $order->module !== 'econtdeliverypayment') return null;

        if (!$this->active || $order->id_carrier != Configuration::get('ECONT_DELIVERY_CARRIER_ID')) return $this->orderConfirmationMessage('Улугата не е активна');

        $customer = new Customer($order->id_customer);
        if (!Validate::isLoadedObject($customer)) return $this->orderConfirmationMessage('Невалиден купувач');

        $deliveryBaseURL = Configuration::get('ECONT_DELIVERY_ENDPOINT');
        $deliverySecret = Configuration::get('ECONT_DELIVERY_SECRET');
        if(!$deliveryBaseURL || !$deliverySecret) return $this->orderConfirmationMessage('Невалидна конфигурация');

        if (!hash_equals(EcontDelivery::getProtectionHash(array(
                'id_order' => (string)@$order->id,
                'econtdeliverypayment_transaction_id' => (string)@$_GET['econtdeliverypayment_transaction_id'],
                'econtdeliverypayment_time' => (string)@$_GET['econtdeliverypayment_time']
            )), (string)@$_GET['econtdeliverypayment_hash'])) return $this->orderConfirmationMessage('Невалидна трансакция');

        // Подписаният адрес важи RETURN_URL_TTL секунди и само докато поръчката чака плащането
        $returnTime = (int)@$_GET['econtdeliverypayment_time'];
        if ($returnTime > time() + 300 || time() - $returnTime > self::RETURN_URL_TTL) return $this->orderConfirmationMessage('Връзката за потвърждение на плащането е изтекла');
        if (!EcontDelivery::updateOrderStatus($order, $this->context->language->id)) return null;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "{$deliveryBaseURL}/services/PaymentsService.confirmPayment.json");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            "Authorization: {$deliverySecret}"
        ]);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(array(
            'paymentIdentifier' => $_GET['econtdeliverypayment_transaction_id']
        )));
        curl_setopt($curl, CURLOPT_TIMEOUT, 6);
        $response = json_decode(curl_exec($curl), true);
        $responseInfo = curl_getinfo($curl);

        if ($responseInfo['http_code'] !== 200) $response['error'] = $response;
        curl_close($curl);

        if (!empty($response['error'])) {
            if (EcontDelivery::updateOrderStatus($order, $this->context->language->id)) $this->setOrderCurrentState($order, Configuration::get('PS_OS_ERROR'));
            return $this->orderConfirmationMessage($response['message'], true);
        } elseif (empty($response['paymentToken'])) {
            if (EcontDelivery::updateOrderStatus($order, $this->context->language->id)) $this->setOrderCurrentState($order, Configuration::get('PS_OS_ERROR'));
            return $this->orderConfirmationMessage('Възникна проблем при приключване на плащане');
        }

        if (EcontDelivery::updateOrderStatus($order, $this->context->language->id)) $this->orderConfirmationMessage('Не е възможно да се промени статуса на плащането');

        $this->setOrderCurrentState($order, Configuration::get('PS_OS_PAYMENT'));
        $econtDelivery = new EcontDelivery();
        $econtDelivery->syncOrder($order->id, $response['paymentToken']);
        $this->setOrderCurrentState($order, Configuration::get('PS_OS_PREPARATION'));
    }

    public static function setOrderCurrentState($order, $state) {
        $orderHistory = new OrderHistory();
        $orderHistory->id_order = (int) $order->id;
        $orderHistory->changeIdOrderState((int) $state, $order, true);
        return $orderHistory->addWithemail();
    }

}
